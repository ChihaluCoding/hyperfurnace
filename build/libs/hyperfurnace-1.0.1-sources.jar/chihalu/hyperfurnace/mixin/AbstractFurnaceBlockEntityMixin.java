package chihalu.hyperfurnace.mixin;

import chihalu.hyperfurnace.furnace.FurnaceSpeedAccessor;
import chihalu.hyperfurnace.furnace.FurnaceSpeedLevels;
import chihalu.hyperfurnace.furnace.FurnaceSpeedPropertyDelegate;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1874;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3866;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2609.class)
public abstract class AbstractFurnaceBlockEntityMixin implements FurnaceSpeedAccessor {
    private static final String SPEED_KEY = "hyperfurnace_speed";

    @Mutable
    @Shadow
    @Final
    protected class_3913 propertyDelegate;

    @Shadow
    int cookingTimeSpent;

    @Shadow
    int cookingTotalTime;

    @Unique
    private int hyperfurnace$speedLevel;

    @Unique
    private int hyperfurnace$baseCookTime;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void hyperfurnace$init(class_2591<?> type, class_2338 pos, class_2680 state, class_3956<? extends class_1874> recipeType, CallbackInfo ci) {
        if ((Object) this instanceof class_3866) {
            this.propertyDelegate = new FurnaceSpeedPropertyDelegate(this.propertyDelegate, this);
        }
    }

    @Inject(method = "writeData", at = @At("TAIL"))
    private void hyperfurnace$writeSpeed(class_11372 data, CallbackInfo ci) {
        if ((Object) this instanceof class_3866) {
            data.method_71465(SPEED_KEY, this.hyperfurnace$speedLevel);
        }
    }

    @Inject(method = "readData", at = @At("TAIL"))
    private void hyperfurnace$readSpeed(class_11368 view, CallbackInfo ci) {
        if ((Object) this instanceof class_3866) {
            this.hyperfurnace$setSpeedLevelInternal(view.method_71424(SPEED_KEY, 0), false);
        }
    }

    @Inject(method = "getCookTime", at = @At("RETURN"), cancellable = true)
    private static void hyperfurnace$adjustCookTime(class_3218 world, class_2609 furnace, CallbackInfoReturnable<Integer> cir) {
        if (!(furnace instanceof class_3866)) {
            return;
        }

        int base = Math.max(1, cir.getReturnValue());
        FurnaceSpeedAccessor accessor = (FurnaceSpeedAccessor) furnace;
        accessor.hyperfurnace$setBaseCookTime(base);

        int speed = accessor.hyperfurnace$getSpeedLevel();
        int adjusted = hyperfurnace$computeCookTime(base, speed);
        if (adjusted == base) {
            return;
        }

        cir.setReturnValue(adjusted);
        ((AbstractFurnaceBlockEntityMixin) (Object) furnace).hyperfurnace$applyCookTimeAdjustment(base, adjusted);
    }

    @Override
    public int hyperfurnace$getSpeedLevel() {
        return this.hyperfurnace$speedLevel;
    }

    @Override
    public void hyperfurnace$setSpeedLevel(int level) {
        if ((Object) this instanceof class_3866) {
            this.hyperfurnace$setSpeedLevelInternal(level, true);
        }
    }

    @Override
    public void hyperfurnace$setSpeedLevelFromSync(int level) {
        this.hyperfurnace$setSpeedLevelInternal(level, false);
    }

    @Override
    public void hyperfurnace$setBaseCookTime(int cookTime) {
        this.hyperfurnace$baseCookTime = cookTime;
    }

    @Override
    public int hyperfurnace$getBaseCookTime() {
        return this.hyperfurnace$baseCookTime;
    }

    @Unique
    private void hyperfurnace$setSpeedLevelInternal(int level, boolean markDirty) {
        int clamped = FurnaceSpeedLevels.clamp(level);
        if (clamped == this.hyperfurnace$speedLevel) {
            return;
        }

        int previousSpeed = this.hyperfurnace$speedLevel;
        this.hyperfurnace$speedLevel = clamped;

        int base = this.hyperfurnace$baseCookTime;
        if (base <= 0) {
            base = Math.max(1, Math.round((float) this.cookingTotalTime * FurnaceSpeedLevels.multiplier(previousSpeed)));
        }

        this.hyperfurnace$baseCookTime = base;
        int newTotal = hyperfurnace$computeCookTime(base, clamped);
        this.hyperfurnace$applyCookTimeAdjustment(Math.max(1, base), newTotal);

        if (markDirty) {
            ((class_2609) (Object) this).method_5431();
        }
    }

    @Unique
    private void hyperfurnace$applyCookTimeAdjustment(int base, int adjusted) {
        if (this.cookingTotalTime == adjusted) {
            return;
        }

        if (this.cookingTotalTime > 0) {
            this.cookingTimeSpent = class_3532.method_15340((int) Math.round(this.cookingTimeSpent * (double) adjusted / this.cookingTotalTime), 0, adjusted);
        }
        this.cookingTotalTime = adjusted;
    }

    @Unique
    private static int hyperfurnace$computeCookTime(int base, int level) {
        int multiplier = FurnaceSpeedLevels.multiplier(level);
        return Math.max(1, (int) Math.ceil((double) base / multiplier));
    }
}
