package chihalu.hyperfurnace.mixin.client;

import chihalu.hyperfurnace.furnace.FurnaceScreenHandlerAccess;
import chihalu.hyperfurnace.furnace.FurnaceSpeedLevels;
import chihalu.hyperfurnace.furnace.FurnaceSpeedPropertyDelegate;
import chihalu.hyperfurnace.network.HyperFurnaceClientNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_1720;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3858;
import net.minecraft.class_3913;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_489;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_489.class)
public abstract class FurnaceScreenMixin extends class_465<class_1720> {
    @Unique
    private class_4185 hyperfurnace$speedButton;

    @Unique
    private int hyperfurnace$speedValue;
    @Unique
    private static final int hyperfurnace$buttonWidth = 80;
    @Unique
    private static final int hyperfurnace$buttonHeight = 20;

    protected FurnaceScreenMixin(class_1720 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "init()V", at = @At("TAIL"))
    private void hyperfurnace$addSpeedButton(CallbackInfo ci) {
        if (!(this.field_2797 instanceof class_3858)) {
            return;
        }

        this.hyperfurnace$speedValue = this.hyperfurnace$getDelegateSpeed();
        int buttonX = this.hyperfurnace$getButtonX();
        int buttonY = this.hyperfurnace$getButtonY();

        this.hyperfurnace$speedButton = class_4185.method_46430(class_2561.method_43473(), button -> {
            int nextValue = FurnaceSpeedLevels.next(this.hyperfurnace$speedValue);
            this.hyperfurnace$setSpeed(nextValue, true);
            HyperFurnaceClientNetworking.sendSpeedUpdate((class_3858) this.field_2797, nextValue);
        }).method_46434(buttonX, buttonY, hyperfurnace$buttonWidth, hyperfurnace$buttonHeight).method_46431();
        this.hyperfurnace$speedButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.hyperfurnace.speed.tooltip")));

        this.hyperfurnace$refreshSpeedLabel();
        this.method_37063(this.hyperfurnace$speedButton);
    }

    @Inject(method = "drawBackground(Lnet/minecraft/client/gui/DrawContext;FII)V", at = @At("HEAD"))
    private void hyperfurnace$syncSpeedFromServer(class_332 context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        if (!(this.field_2797 instanceof class_3858)) {
            return;
        }

        if (this.hyperfurnace$speedButton != null) {
            this.hyperfurnace$speedButton.method_48229(this.hyperfurnace$getButtonX(), this.hyperfurnace$getButtonY());
        }

        int delegateValue = this.hyperfurnace$getDelegateSpeed();
        if (delegateValue != this.hyperfurnace$speedValue) {
            this.hyperfurnace$setSpeed(delegateValue, false);
        }
    }

    @Unique
    private int hyperfurnace$getDelegateSpeed() {
        if (!(this.field_2797 instanceof class_3858)) {
            return 0;
        }
        class_3913 delegate = ((FurnaceScreenHandlerAccess) this.field_2797).hyperfurnace$getPropertyDelegate();
        return FurnaceSpeedLevels.clamp(delegate.method_17390(FurnaceSpeedPropertyDelegate.SPEED_INDEX));
    }

    @Unique
    private void hyperfurnace$setSpeed(int newValue, boolean updateDelegate) {
        this.hyperfurnace$speedValue = FurnaceSpeedLevels.clamp(newValue);
        if (updateDelegate) {
            class_3913 delegate = ((FurnaceScreenHandlerAccess) this.field_2797).hyperfurnace$getPropertyDelegate();
            delegate.method_17391(FurnaceSpeedPropertyDelegate.SPEED_INDEX, this.hyperfurnace$speedValue);
        }
        this.hyperfurnace$refreshSpeedLabel();
    }

    @Unique
    private void hyperfurnace$refreshSpeedLabel() {
        if (this.hyperfurnace$speedButton != null) {
            this.hyperfurnace$speedButton.method_25355(class_2561.method_43469("gui.hyperfurnace.speed.button", FurnaceSpeedLevels.multiplier(this.hyperfurnace$speedValue)));
        }
    }

    @Unique
    private int hyperfurnace$getButtonX() {
        return this.field_2776 + this.field_2792 - hyperfurnace$buttonWidth - 6;
    }

    @Unique
    private int hyperfurnace$getButtonY() {
        return this.field_2800 + 35 + 24;
    }
}
