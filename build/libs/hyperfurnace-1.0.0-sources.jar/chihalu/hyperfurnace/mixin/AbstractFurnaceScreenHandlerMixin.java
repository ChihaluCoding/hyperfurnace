package chihalu.hyperfurnace.mixin;

import chihalu.hyperfurnace.furnace.FurnaceScreenHandlerAccess;
import net.minecraft.class_1263;
import net.minecraft.class_1720;
import net.minecraft.class_3913;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_1720.class)
public abstract class AbstractFurnaceScreenHandlerMixin implements FurnaceScreenHandlerAccess {
    @Shadow @Final class_1263 inventory;

    @Shadow @Final private class_3913 propertyDelegate;

    @Override
    public class_3913 hyperfurnace$getPropertyDelegate() {
        return this.propertyDelegate;
    }

    @Override
    public class_1263 hyperfurnace$getInventory() {
        return this.inventory;
    }

    @ModifyConstant(
            method = "<init>(Lnet/minecraft/screen/ScreenHandlerType;Lnet/minecraft/recipe/RecipeType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/recipe/book/RecipeBookType;ILnet/minecraft/entity/player/PlayerInventory;)V",
            constant = @Constant(intValue = 4)
    )
    private static int hyperfurnace$expandClientPropertySize(int original) {
        return 5;
    }
}
