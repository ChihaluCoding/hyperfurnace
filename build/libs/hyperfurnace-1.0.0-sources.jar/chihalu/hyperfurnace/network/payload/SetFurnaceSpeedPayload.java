package chihalu.hyperfurnace.network.payload;

import chihalu.hyperfurnace.HyperFurnace;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SetFurnaceSpeedPayload(int syncId, int speedLevel) implements class_8710 {
    public static final class_9154<SetFurnaceSpeedPayload> ID = new class_9154<>(class_2960.method_60655(HyperFurnace.MOD_ID, "set_furnace_speed"));
    public static final class_9139<class_9129, SetFurnaceSpeedPayload> CODEC = class_9139.method_56438(SetFurnaceSpeedPayload::write, SetFurnaceSpeedPayload::read);

    private static void write(SetFurnaceSpeedPayload payload, class_9129 buf) {
        buf.method_10804(payload.syncId());
        buf.method_10804(payload.speedLevel());
    }

    private static SetFurnaceSpeedPayload read(class_9129 buf) {
        return new SetFurnaceSpeedPayload(buf.method_10816(), buf.method_10816());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
