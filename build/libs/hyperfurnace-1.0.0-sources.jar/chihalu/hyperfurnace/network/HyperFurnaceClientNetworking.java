package chihalu.hyperfurnace.network;

import chihalu.hyperfurnace.network.payload.SetFurnaceSpeedPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_3858;

public final class HyperFurnaceClientNetworking {
    private HyperFurnaceClientNetworking() {
    }

    public static void sendSpeedUpdate(class_3858 handler, int speedLevel) {
        ClientPlayNetworking.send(new SetFurnaceSpeedPayload(handler.field_7763, speedLevel));
    }
}
