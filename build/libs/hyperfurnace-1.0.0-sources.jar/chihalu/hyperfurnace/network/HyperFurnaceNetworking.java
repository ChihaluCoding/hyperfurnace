package chihalu.hyperfurnace.network;

import chihalu.hyperfurnace.furnace.FurnaceScreenHandlerAccess;
import chihalu.hyperfurnace.furnace.FurnaceSpeedAccessor;
import chihalu.hyperfurnace.furnace.FurnaceSpeedLevels;
import chihalu.hyperfurnace.network.payload.SetFurnaceSpeedPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_3222;
import net.minecraft.class_3858;
import net.minecraft.class_3866;

public final class HyperFurnaceNetworking {
    private static boolean registered;

    private HyperFurnaceNetworking() {
    }

    public static void registerCommon() {
        if (registered) {
            return;
        }
        registered = true;
        PayloadTypeRegistry.playC2S().register(SetFurnaceSpeedPayload.ID, SetFurnaceSpeedPayload.CODEC);
    }

    public static void registerServer() {
        registerCommon();
        ServerPlayNetworking.registerGlobalReceiver(SetFurnaceSpeedPayload.ID, (payload, context) -> handleSpeedUpdate((class_3222) context.player(), payload.syncId(), payload.speedLevel()));
    }

    private static void handleSpeedUpdate(class_3222 player, int syncId, int requestedSpeed) {
        if (player.field_7512 == null || player.field_7512.field_7763 != syncId) {
            return;
        }

        if (!(player.field_7512 instanceof class_3858 furnaceHandler)) {
            return;
        }

        int clampedSpeed = FurnaceSpeedLevels.clamp(requestedSpeed);
        FurnaceScreenHandlerAccess access = (FurnaceScreenHandlerAccess) furnaceHandler;
        class_1263 inventory = access.hyperfurnace$getInventory();
        if (inventory instanceof class_3866 furnace) {
            ((FurnaceSpeedAccessor) furnace).hyperfurnace$setSpeedLevel(clampedSpeed);
        }
    }
}
