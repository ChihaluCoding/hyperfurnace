package chihalu.hyperfurnace.furnace;

import net.minecraft.class_3532;

public final class FurnaceSpeedLevels {
    private static final int[] MULTIPLIERS = {1, 5, 10, 15, 20, 25, 30};

    private FurnaceSpeedLevels() {
    }

    public static int clamp(int level) {
        return class_3532.method_15340(level, 0, MULTIPLIERS.length - 1);
    }

    public static int next(int level) {
        return (level + 1) % MULTIPLIERS.length;
    }

    public static int multiplier(int level) {
        return MULTIPLIERS[clamp(level)];
    }

    public static int count() {
        return MULTIPLIERS.length;
    }
}
