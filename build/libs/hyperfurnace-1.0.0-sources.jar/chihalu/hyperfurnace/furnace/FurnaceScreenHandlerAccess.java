package chihalu.hyperfurnace.furnace;

import net.minecraft.class_1263;
import net.minecraft.class_3913;

public interface FurnaceScreenHandlerAccess {
    class_3913 hyperfurnace$getPropertyDelegate();

    class_1263 hyperfurnace$getInventory();
}
