package chihalu.hyperfurnace.furnace;

import net.minecraft.class_3913;

public final class FurnaceSpeedPropertyDelegate implements class_3913 {
    public static final int SPEED_INDEX = 4;

    private final class_3913 base;
    private final FurnaceSpeedAccessor accessor;

    public FurnaceSpeedPropertyDelegate(class_3913 base, FurnaceSpeedAccessor accessor) {
        this.base = base;
        this.accessor = accessor;
    }

    @Override
    public int method_17390(int index) {
        if (index == SPEED_INDEX) {
            return this.accessor.hyperfurnace$getSpeedLevel();
        }
        return this.base.method_17390(index);
    }

    @Override
    public void method_17391(int index, int value) {
        if (index == SPEED_INDEX) {
            this.accessor.hyperfurnace$setSpeedLevelFromSync(FurnaceSpeedLevels.clamp(value));
            return;
        }
        this.base.method_17391(index, value);
    }

    @Override
    public int method_17389() {
        return this.base.method_17389() + 1;
    }
}
